# Texto do TCC — versão para a pré-banca (22/10/2026)

Versão 2, de 29/09/2026. Gerada a partir de `TCC_OFICIAL_REAL 14.pdf`, dos resultados do
repositório NISQ-Predictive-Twin e dos dois manuscritos do autor (qnet_autopilot e camada
de ML para QKD).

## Como compilar

- **Overleaf:** Novo projeto → Upload Project → enviar o `.zip`. Compilador pdfLaTeX; o BibTeX
  roda automaticamente.
- **Template oficial da SBC:** `sbc-template.sty` e `sbc.bst` são réplicas locais. Se o projeto
  usar o template oficial, apague os dois; `main.tex` usa apenas os comandos do oficial.

## Pendências (em vermelho no PDF, marcadas com `\pendente{}`)

1. Resultado em laço fechado no Abstract, no Resumo e na Conclusão.
2. Extensão do fluxo de ativação para os modelos do catálogo (Seção 7.5).
3. Contagem de testes aprovados após a correção do CI (Seção 7.6).
4. Protocolo congelado e hash da campanha em laço fechado (Seção 8.3). A planta prevista é o
   modelo de fibra do qnet_autopilot no ponto calibrado, que é o domínio de treino dos pesos.
5. Tabela e texto da campanha em laço fechado (Seção 9.3).

## Manuscritos do autor

- Estão citados como `@unpublished`, com a nota "Manuscrito não publicado". A Seção 6 resume
  o método e os resultados deles, para que o TCC se sustente sem acesso aos manuscritos.
- Para dar à banca acesso ao texto completo, há duas opções:
  - depositar os dois como preprint (arXiv ou Zenodo; o Zenodo emite DOI no mesmo dia) e
    trocar a nota pelo identificador;
  - anexá-los como apêndices, se o regulamento do curso permitir.
- Um detalhe para corrigir nos manuscritos: Shi et al. (2026), arXiv:2601.11753, aparece
  como "Shi, Y., Su, J." no qnet_autopilot e como "Shi, S., Su, Y." no artigo de QKD. Uma das
  duas grafias está errada. As outras referências recentes que conferi existem: Ramaswamy (2026),
  Young (2026), Tezzin (2026), Rode (2025) e Zhang (2021).

## Referências

- **Removidas por não terem sido encontradas:** Cao, Yehia e Tura (2023); Chen, Li e Vincent (2025);
  Dietsche, Dür e Dunjko (2022); Peters, Rosas-Fernandez e Spiller (2023); Wang, Zhang e Xu (2025);
  Zhuang e Zhang (2024).
- **Corrigida:** Krutyanskiy et al. (2023), que tinha a lista de autores de outro artigo do grupo.
- **Todas as entradas atuais** foram conferidas por título, periódico e ano. Antes da versão final,
  exporte o BibTeX pelo DOI (Google Scholar ou doi.org) das entradas com "et al." na lista de autores:
  Patel, Xavier, Thomas, Coopmans, Gavignet, Javadi-Abhari e Paszke.
- Os conjuntos de dados (Sant'Anna, IrelandQCI e Bristol) estão em notas de rodapé com URL/DOI.

## Novidades da versão 2

- Nova Seção 6, "Controladores Aprendidos": método comum e tabela com os resultados dos
  manuscritos, inclusive os negativos.
- Título do objetivo, pergunta de pesquisa, contribuições, Abstract, Resumo e Conclusão
  incluem os modelos como contribuição científica.
- Corrigido: os modelos foram treinados sobre uma transcrição do SeQUeNCe conferida contra
  ele, e não no próprio SeQUeNCe.
- A Discussão explica por que o MLP falhou no ORION-Q e empata com o Ridge no manuscrito: o
  produtor artificial usa vibração de ~0,003 rad RMS, sem ruído de fótons, contra 0,3 rad RMS
  no treino.
- Referências novas: Dynes et al. (2019), Tomamichel et al. (2012) e Wang e Lo (2019).

## Correções em relação à versão 14

- Objetivo e título alinhados ao foco atual: plataforma de controle com modelos acoplados.
- O ruído de Ornstein-Uhlenbeck agora é descrito como markoviano; antes o texto o chamava de "não markoviano".
- A RUC deixou de aparecer como resultado: era definida, mas nunca estimada.
- Figuras 2, 3, 5, 6 e 7 da versão 14 foram removidas. As legendas não correspondiam aos gráficos,
  e a Figura 7 contradizia o texto.
- A figura multi-salto foi reinterpretada: a taxa de sucesso é condicionada à admissão, não mede vazão.
- O ranking por custo físico agora vem com a ressalva de que depende do peso α = 100.
- A Fase 2 deixou de ser descrita como trabalho futuro.
- Resultados do estudo preliminar alinhados ao repositório: protocolo congelado v5.26, 0 de 3
  comparações neurais significativas contra persistência.
- Nova seção de arquitetura, nova seção de modelos, campanhas shadow (figura nova com os dados
  dos relatórios de 23/09) e conclusão, que não existia.

## Conferir

- Se os coautores concordam com o novo enfoque.
- As Figuras 1 e 2 foram extraídas do PDF antigo, com texto em inglês e resolução limitada.
  Se possível, regenere-as pelos scripts do repositório.
