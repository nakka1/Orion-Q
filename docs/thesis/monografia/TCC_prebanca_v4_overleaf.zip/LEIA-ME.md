# Texto do TCC — versão para a pré-banca (22/10/2026)

Versão 4, de 29/09/2026. Acrescenta à versão 3 o compensador em laço fechado
supervisionado dentro do ORION-Q e a ativação dele pelo fluxo Q05. Formato de artigo SBC;
36 páginas.

## Como compilar

- **Overleaf:** Novo projeto → Upload Project → enviar o `.zip`. Compilador pdfLaTeX; o BibTeX
  roda automaticamente.
- **Template oficial da SBC:** `sbc-template.sty` e `sbc.bst` são réplicas locais. Se o projeto
  usar o template oficial, apague os dois; `main.tex` usa apenas os comandos do oficial.

## Pendências (em vermelho no PDF, marcadas com `\pendente{}`)

1. Endereço do repositório versionado do qnet_autopilot (Disponibilidade). O código dele
   sustenta resultados do TCC e precisa estar versionado como o ORION-Q.

## Novidades da versão 4

- Resumo e Abstract: resultado em laço fechado (20 sementes novas, 3,3 vezes abaixo do
  alfa-beta, p de Holm < 10⁻⁵, falha injetada contida pelo supervisor).
- Seção 9.5: extensão do fluxo de ativação ao alvo de polarização, com a evidência da
  campanha vinculada ao hash dos pesos.
- Seção 10.3: protocolo real do laço fechado (planta transcrita e conferida, supervisor,
  contrato, sementes, ressintonia, teste de sinais exato com Holm, portão de reprodução).
- Seção 11.3: Tabela 10 e texto dos resultados; o MLP volta a empatar com o Ridge na
  planta certa.
- Discussão, limitações e conclusão ajustadas; trabalhos futuros sem o item já feito.
- Seção 9.6: 3.605 testes; em Linux, 3.602 passam e 3 são próprios do Windows (execução de
  29/09 na nuvem). Confirmar no Windows antes da versão final.

## Como os manuscritos foram incorporados

- Não são mais citados; o conteúdo virou parte do texto:
  - física de estados-isca e chave finita: Seções 3.2 e 3.3;
  - trabalhos relacionados: Seção 4;
  - substrato físico, modelo de fibra, ataques e regras de avaliação: Seção 6;
  - controladores de rede: Seção 7;
  - controladores de QKD e validação com os dados de Cambridge: Seção 8;
  - limitações dos dois trabalhos: Seção 12.
- Mantidas com os números originais: Tabelas 1 e 2 do qnet_autopilot, Tabelas 1, 3, 7 e 8 do
  artigo de QKD, e as Figuras 5 (qnet) e 1, 3 e 6 (QKD), recortadas dos PDFs.
- Resumidos ou omitidos: a arquitetura de software do pacote; o compensador convolucional (TCN),
  que empatou com a rede densa; parte dos detalhes do RTL e do porte para ponto fixo; e as
  Figuras 1 a 4, 6 e 7 do qnet_autopilot e 2, 4 e 5 do artigo de QKD.
- Conferi mecanicamente que todos os números das Seções 6 a 8 aparecem nos manuscritos.
- A referência Shi et al. (2026) usa os autores corretos ("Shi, Y., Su, J."), conferidos no arXiv.
  O artigo de QKD grafava "Shi, S., Su, Y.".

## Referências

- **Removidas por não terem sido encontradas:** Cao, Yehia e Tura (2023); Chen, Li e Vincent (2025);
  Dietsche, Dür e Dunjko (2022); Peters, Rosas-Fernandez e Spiller (2023); Wang, Zhang e Xu (2025);
  Zhuang e Zhang (2024).
- **Corrigida:** Krutyanskiy et al. (2023), que tinha a lista de autores de outro artigo do grupo.
- **Todas as entradas atuais** foram conferidas por título, periódico e ano. Antes da versão final,
  exporte o BibTeX pelo DOI (Google Scholar ou doi.org) das entradas com "et al." na lista de autores:
  Patel, Xavier, Thomas, Coopmans, Gavignet, Javadi-Abhari e Paszke.
- Os conjuntos de dados (Sant'Anna, IrelandQCI e Bristol) estão em notas de rodapé com URL/DOI.

## Novidades da versão 3

- Título: "Controladores Aprendidos e uma Plataforma de Controle Auditável".
- Pergunta de pesquisa, objetivos, contribuições, resumos, discussão e conclusão tratam os
  controladores como resultado do próprio TCC.
- 34 referências novas, herdadas dos manuscritos e conferidas (66 no total).

## Novidades da versão 2

- Nova Seção 6, "Controladores Aprendidos": método comum e tabela com os resultados dos
  manuscritos, inclusive os negativos.
- Título do objetivo, pergunta de pesquisa, contribuições, Abstract, Resumo e Conclusão
  incluem os modelos como contribuição científica.
- Corrigido: os modelos foram treinados sobre uma transcrição do SeQUeNCe conferida contra
  ele, e não no próprio SeQUeNCe.
- A Discussão explica por que o MLP falhou no ORION-Q e empata com o Ridge no manuscrito: o
  produtor artificial usa vibração de ~0,003 rad RMS, sem ruído de fótons, contra 0,3 rad RMS
  no treino.
- Referências novas: Dynes et al. (2019), Tomamichel et al. (2012) e Wang e Lo (2019).

## Correções em relação à versão 14

- Objetivo e título alinhados ao foco atual: plataforma de controle com modelos acoplados.
- O ruído de Ornstein-Uhlenbeck agora é descrito como markoviano; antes o texto o chamava de "não markoviano".
- A RUC deixou de aparecer como resultado: era definida, mas nunca estimada.
- Figuras 2, 3, 5, 6 e 7 da versão 14 foram removidas. As legendas não correspondiam aos gráficos,
  e a Figura 7 contradizia o texto.
- A figura multi-salto foi reinterpretada: a taxa de sucesso é condicionada à admissão, não mede vazão.
- O ranking por custo físico agora vem com a ressalva de que depende do peso α = 100.
- A Fase 2 deixou de ser descrita como trabalho futuro.
- Resultados do estudo preliminar alinhados ao repositório: protocolo congelado v5.26, 0 de 3
  comparações neurais significativas contra persistência.
- Nova seção de arquitetura, nova seção de modelos, campanhas shadow (figura nova com os dados
  dos relatórios de 23/09) e conclusão, que não existia.

## Conferir

- Se os coautores concordam com o novo enfoque.
- As Figuras 1 e 2 foram extraídas do PDF antigo, com texto em inglês e resolução limitada.
  Se possível, regenere-as pelos scripts do repositório.
