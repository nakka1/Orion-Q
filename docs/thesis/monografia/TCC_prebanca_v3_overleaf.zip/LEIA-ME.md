# Texto do TCC — versão para a pré-banca (22/10/2026)

Versão 3, de 29/09/2026. Unifica ao TCC os dois manuscritos do autor (qnet_autopilot e camada
de ML para QKD), que não serão publicados. Parte de `TCC_OFICIAL_REAL 14.pdf` e dos resultados do
repositório NISQ-Predictive-Twin. Formato de artigo SBC; 34 páginas.

## Como compilar

- **Overleaf:** Novo projeto → Upload Project → enviar o `.zip`. Compilador pdfLaTeX; o BibTeX
  roda automaticamente.
- **Template oficial da SBC:** `sbc-template.sty` e `sbc.bst` são réplicas locais. Se o projeto
  usar o template oficial, apague os dois; `main.tex` usa apenas os comandos do oficial.

## Pendências (em vermelho no PDF, marcadas com `\pendente{}`)

1. Resultado em laço fechado no Abstract, no Resumo e na Conclusão.
2. Extensão do fluxo de ativação para os modelos do catálogo (Seção 9.5).
3. Contagem de testes aprovados após a correção do CI (Seção 9.6).
4. Protocolo congelado e hash da campanha em laço fechado (Seção 10.3). A planta prevista é o
   modelo de fibra do qnet_autopilot no ponto calibrado, que é o domínio de treino dos pesos.
5. Tabela e texto da campanha em laço fechado (Seção 11.3).
6. Endereço do repositório versionado do qnet_autopilot (Disponibilidade). O código dele agora
   sustenta resultados do TCC, então precisa estar versionado como o ORION-Q.

## Como os manuscritos foram incorporados

- Não são mais citados; o conteúdo virou parte do texto:
  - física de estados-isca e chave finita: Seções 3.2 e 3.3;
  - trabalhos relacionados: Seção 4;
  - substrato físico, modelo de fibra, ataques e regras de avaliação: Seção 6;
  - controladores de rede: Seção 7;
  - controladores de QKD e validação com os dados de Cambridge: Seção 8;
  - limitações dos dois trabalhos: Seção 12.
- Mantidas com os números originais: Tabelas 1 e 2 do qnet_autopilot, Tabelas 1, 3, 7 e 8 do
  artigo de QKD, e as Figuras 5 (qnet) e 1, 3 e 6 (QKD), recortadas dos PDFs.
- Resumidos ou omitidos: a arquitetura de software do pacote; o compensador convolucional (TCN),
  que empatou com a rede densa; parte dos detalhes do RTL e do porte para ponto fixo; e as
  Figuras 1 a 4, 6 e 7 do qnet_autopilot e 2, 4 e 5 do artigo de QKD.
- Conferi mecanicamente que todos os números das Seções 6 a 8 aparecem nos manuscritos.
- A referência Shi et al. (2026) usa os autores corretos ("Shi, Y., Su, J."), conferidos no arXiv.
  O artigo de QKD grafava "Shi, S., Su, Y.".

## Referências

- **Removidas por não terem sido encontradas:** Cao, Yehia e Tura (2023); Chen, Li e Vincent (2025);
  Dietsche, Dür e Dunjko (2022); Peters, Rosas-Fernandez e Spiller (2023); Wang, Zhang e Xu (2025);
  Zhuang e Zhang (2024).
- **Corrigida:** Krutyanskiy et al. (2023), que tinha a lista de autores de outro artigo do grupo.
- **Todas as entradas atuais** foram conferidas por título, periódico e ano. Antes da versão final,
  exporte o BibTeX pelo DOI (Google Scholar ou doi.org) das entradas com "et al." na lista de autores:
  Patel, Xavier, Thomas, Coopmans, Gavignet, Javadi-Abhari e Paszke.
- Os conjuntos de dados (Sant'Anna, IrelandQCI e Bristol) estão em notas de rodapé com URL/DOI.

## Novidades da versão 3

- Título: "Controladores Aprendidos e uma Plataforma de Controle Auditável".
- Pergunta de pesquisa, objetivos, contribuições, resumos, discussão e conclusão tratam os
  controladores como resultado do próprio TCC.
- 34 referências novas, herdadas dos manuscritos e conferidas (66 no total).

## Novidades da versão 2

- Nova Seção 6, "Controladores Aprendidos": método comum e tabela com os resultados dos
  manuscritos, inclusive os negativos.
- Título do objetivo, pergunta de pesquisa, contribuições, Abstract, Resumo e Conclusão
  incluem os modelos como contribuição científica.
- Corrigido: os modelos foram treinados sobre uma transcrição do SeQUeNCe conferida contra
  ele, e não no próprio SeQUeNCe.
- A Discussão explica por que o MLP falhou no ORION-Q e empata com o Ridge no manuscrito: o
  produtor artificial usa vibração de ~0,003 rad RMS, sem ruído de fótons, contra 0,3 rad RMS
  no treino.
- Referências novas: Dynes et al. (2019), Tomamichel et al. (2012) e Wang e Lo (2019).

## Correções em relação à versão 14

- Objetivo e título alinhados ao foco atual: plataforma de controle com modelos acoplados.
- O ruído de Ornstein-Uhlenbeck agora é descrito como markoviano; antes o texto o chamava de "não markoviano".
- A RUC deixou de aparecer como resultado: era definida, mas nunca estimada.
- Figuras 2, 3, 5, 6 e 7 da versão 14 foram removidas. As legendas não correspondiam aos gráficos,
  e a Figura 7 contradizia o texto.
- A figura multi-salto foi reinterpretada: a taxa de sucesso é condicionada à admissão, não mede vazão.
- O ranking por custo físico agora vem com a ressalva de que depende do peso α = 100.
- A Fase 2 deixou de ser descrita como trabalho futuro.
- Resultados do estudo preliminar alinhados ao repositório: protocolo congelado v5.26, 0 de 3
  comparações neurais significativas contra persistência.
- Nova seção de arquitetura, nova seção de modelos, campanhas shadow (figura nova com os dados
  dos relatórios de 23/09) e conclusão, que não existia.

## Conferir

- Se os coautores concordam com o novo enfoque.
- As Figuras 1 e 2 foram extraídas do PDF antigo, com texto em inglês e resolução limitada.
  Se possível, regenere-as pelos scripts do repositório.
